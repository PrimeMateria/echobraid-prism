/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

export const UNIVERSAL_LOGIC_DEMO_HTML = `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
  :root { 
    --bg: #09090b; 
    --panel: #18181b; 
    --border: #27272a; 
    --accent: #3b82f6; 
    --text: #e4e4e7; 
    --text-dim: #a1a1aa; 
    --success: #22c55e; 
    --error: #ef4444; 
    --warn: #eab308; 
    --quantum: #a855f7;
    --fuzzy: #eab308;
    --classical: #3b82f6;
  }
  body { background: var(--bg); color: var(--text); font-family: 'Inter', system-ui, sans-serif; margin: 0; display: flex; flex-direction: column; height: 100vh; overflow: hidden; }
  .grid-bg { background-image: radial-gradient(var(--border) 1px, transparent 1px); background-size: 24px 24px; }
  
  header { 
    border-bottom: 1px solid var(--border); 
    padding: 1rem 1.5rem; 
    display: flex; 
    justify-content: space-between; 
    align-items: center; 
    background: rgba(9,9,11,0.8); 
    backdrop-filter: blur(8px); 
    z-index: 50;
  }
  
  h1 { font-size: 1.25rem; font-weight: 600; margin: 0; letter-spacing: -0.025em; display: flex; align-items: center; gap: 0.75rem; }
  
  .badge { font-size: 0.7rem; font-weight: 600; padding: 0.25rem 0.75rem; border-radius: 9999px; background: var(--panel); color: var(--text-dim); border: 1px solid var(--border); display: flex; align-items: center; gap: 6px; }
  .badge-dot { width: 6px; height: 6px; border-radius: 50%; background: var(--success); box-shadow: 0 0 8px var(--success); }
  
  main { flex: 1; display: grid; grid-template-columns: 320px 1fr 320px; gap: 1px; background: var(--border); overflow: hidden; }
  
  .panel { background: var(--bg); padding: 1.5rem; display: flex; flex-direction: column; gap: 1.5rem; overflow-y: auto; }
  .panel-title { font-size: 0.75rem; font-weight: 700; color: var(--text-dim); text-transform: uppercase; letter-spacing: 0.1em; display: flex; align-items: center; justify-content: space-between; border-bottom: 1px solid var(--border); padding-bottom: 0.75rem; }
  
  /* Inputs */
  .control-group { background: var(--panel); border: 1px solid var(--border); border-radius: 0.75rem; padding: 1rem; transition: border-color 0.2s; }
  .control-group:hover { border-color: #52525b; }
  .control-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem; }
  .control-label { font-size: 0.875rem; font-weight: 500; color: var(--text); }
  .control-val { font-family: 'JetBrains Mono', monospace; font-size: 0.875rem; color: var(--accent); }
  
  input[type="range"] { 
    width: 100%; 
    appearance: none; 
    background: transparent; 
    cursor: pointer; 
  }
  input[type="range"]::-webkit-slider-runnable-track {
    background: var(--border);
    height: 4px;
    border-radius: 2px;
  }
  input[type="range"]::-webkit-slider-thumb {
    appearance: none;
    background: white;
    width: 16px;
    height: 16px;
    border-radius: 50%;
    margin-top: -6px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.2);
    transition: transform 0.1s;
  }
  input[type="range"]::-webkit-slider-thumb:hover { transform: scale(1.2); }
  
  .switch { position: relative; display: inline-block; width: 48px; height: 26px; }
  .switch input { opacity: 0; width: 0; height: 0; }
  .slider { position: absolute; cursor: pointer; top: 0; left: 0; right: 0; bottom: 0; background-color: var(--border); transition: .4s; border-radius: 34px; }
  .slider:before { position: absolute; content: ""; height: 20px; width: 20px; left: 3px; bottom: 3px; background-color: white; transition: .4s; border-radius: 50%; }
  input:checked + .slider { background-color: var(--classical); }
  input:checked + .slider:before { transform: translateX(22px); }
  
  .algebra-tag { margin-top: 0.75rem; font-size: 0.7rem; color: var(--text-dim); display: flex; gap: 0.5rem; }
  .tag { background: #27272a; padding: 2px 6px; border-radius: 4px; font-family: monospace; }

  /* Visualization Area */
  #viz-container { display: flex; flex-direction: column; align-items: center; justify-content: center; height: 100%; position: relative; background: radial-gradient(circle at center, #18181b 0%, #09090b 100%); }
  
  .node { 
    width: 80px; height: 80px; 
    border-radius: 16px; 
    background: var(--panel); 
    border: 2px solid var(--border); 
    display: flex; flex-direction: column; 
    align-items: center; justify-content: center; 
    position: relative; 
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1); 
    box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.3); 
    z-index: 10; 
  }
  .node-icon { width: 24px; height: 24px; margin-bottom: 4px; opacity: 0.8; }
  .node-label { font-size: 0.7rem; font-weight: 600; text-transform: uppercase; color: var(--text-dim); letter-spacing: 0.05em; margin-bottom: 4px; }
  .node-val { font-family: 'JetBrains Mono', monospace; font-weight: bold; font-size: 1.1rem; color: white; }
  
  /* Node Types */
  .node.fuzzy { border-color: var(--fuzzy); box-shadow: 0 0 20px rgba(234, 179, 8, 0.1); }
  .node.classical { border-color: var(--classical); box-shadow: 0 0 20px rgba(59, 130, 246, 0.1); }
  .node.quantum { border-color: var(--quantum); width: 140px; height: 140px; box-shadow: 0 0 30px rgba(168, 85, 247, 0.15); }
  .node.fusion { border-color: white; width: 100px; height: 100px; background: #27272a; }

  /* Quantum Matrix */
  .q-matrix { display: grid; grid-template-columns: 1fr 1fr; gap: 4px; width: 80%; }
  .q-cell { background: rgba(168, 85, 247, 0.1); border: 1px solid rgba(168, 85, 247, 0.2); border-radius: 4px; padding: 4px; text-align: center; font-family: monospace; font-size: 0.75rem; color: var(--quantum); }

  /* Connections */
  svg { position: absolute; inset: 0; width: 100%; height: 100%; pointer-events: none; }
  path { fill: none; stroke-width: 2px; stroke: var(--border); transition: stroke 0.3s; stroke-dasharray: 1000; stroke-dashoffset: 0; }
  .pulse-path { animation: pulseFlow 2s infinite linear; }
  
  @keyframes pulseFlow {
    0% { stroke-dashoffset: 1000; opacity: 0.2; }
    50% { opacity: 1; }
    100% { stroke-dashoffset: 0; opacity: 0.2; }
  }

  /* CSP Monitor */
  .metric-row { display: flex; justify-content: space-between; align-items: center; padding: 0.75rem 0; border-bottom: 1px solid var(--border); }
  .metric-label { font-size: 0.8rem; color: var(--text-dim); }
  .metric-value { font-family: 'JetBrains Mono', monospace; font-size: 0.9rem; color: white; font-weight: 500; }
  
  .log-container { 
    background: #000; 
    border: 1px solid var(--border); 
    border-radius: 0.5rem; 
    padding: 0.75rem; 
    flex: 1; 
    font-family: 'JetBrains Mono', monospace; 
    font-size: 0.7rem; 
    overflow-y: auto; 
    display: flex; flex-direction: column-reverse; /* New logs at bottom visually but simpler DOM */
  }
  .log-line { padding: 2px 0; border-left: 2px solid transparent; padding-left: 8px; margin-bottom: 2px; animation: fadeIn 0.3s ease-out; }
  .log-line.info { border-color: var(--accent); color: var(--text-dim); }
  .log-line.success { border-color: var(--success); color: var(--text); }
  .log-line.error { border-color: var(--error); color: var(--error); }
  
  @keyframes fadeIn { from { opacity: 0; transform: translateX(-4px); } to { opacity: 1; transform: translateX(0); } }

  /* Fail Closed Overlay */
  #fail-overlay { 
    position: absolute; inset: 0; background: rgba(9,9,11,0.9); backdrop-filter: blur(4px); 
    display: flex; flex-direction: column; align-items: center; justify-content: center; 
    z-index: 100; opacity: 0; pointer-events: none; transition: opacity 0.3s;
  }
  #fail-overlay.active { opacity: 1; pointer-events: auto; }
  .fail-box { border: 1px solid var(--error); background: rgba(239, 68, 68, 0.1); padding: 2rem; border-radius: 1rem; text-align: center; max-width: 400px; }
  .fail-title { color: var(--error); font-size: 1.5rem; font-weight: bold; margin-bottom: 1rem; }
  .fail-desc { color: var(--text); margin-bottom: 1.5rem; line-height: 1.5; }
  .reset-btn { background: var(--error); color: white; border: none; padding: 0.75rem 2rem; border-radius: 0.5rem; font-weight: 600; cursor: pointer; transition: opacity 0.2s; }
  .reset-btn:hover { opacity: 0.9; }

  @media (max-width: 1024px) {
    main { grid-template-columns: 1fr; grid-template-rows: auto 400px auto; overflow-y: auto; }
    body { height: auto; overflow: auto; }
    #viz-container { min-height: 400px; }
  }
</style>
<!-- Load Icons -->
<script src="https://unpkg.com/lucide@latest"></script>
</head>
<body class="grid-bg">
  <header>
    <h1>
      <i data-lucide="cpu" style="color:var(--accent)"></i>
      Universal Logic v2.1+
    </h1>
    <div class="flex gap-2">
      <div class="badge">
        <div class="badge-dot" id="status-dot"></div>
        <span id="status-text">CSP: CERTIFIED</span>
      </div>
    </div>
  </header>

  <main>
    <!-- Left: Inputs -->
    <div class="panel">
      <div class="panel-title">
        <i data-lucide="sliders-horizontal" size="14"></i>
        <span>Signal Inputs</span>
      </div>
      
      <!-- Fuzzy Input -->
      <div class="control-group" style="border-left: 3px solid var(--fuzzy);">
        <div class="control-header">
          <span class="control-label">Fuzzy Sensor (s)</span>
          <span id="val-fuzzy" class="control-val">0.50</span>
        </div>
        <input type="range" id="input-fuzzy" min="0" max="1" step="0.01" value="0.5">
        <div class="algebra-tag">
          <span class="tag">Logic.Fuzzy</span>
          <span class="tag">Product[0,1]</span>
        </div>
      </div>

      <!-- Classical Input -->
      <div class="control-group" style="border-left: 3px solid var(--classical);">
        <div class="control-header">
          <span class="control-label">Classical Rule (r)</span>
          <span id="val-classical" class="control-val">FALSE</span>
        </div>
        <div style="display:flex; justify-content:space-between; align-items:center;">
          <span style="font-size:0.8rem; color:var(--text-dim)">Trigger Active</span>
          <label class="switch">
            <input type="checkbox" id="input-classical">
            <span class="slider"></span>
          </label>
        </div>
        <div class="algebra-tag">
          <span class="tag">Logic.Classical</span>
          <span class="tag">Bool{0,1}</span>
        </div>
      </div>

      <!-- Quantum Noise Input -->
      <div class="control-group" style="border-left: 3px solid var(--quantum);">
        <div class="control-header">
          <span class="control-label">System Noise (ε)</span>
          <span id="val-quantum" class="control-val">0.10</span>
        </div>
        <input type="range" id="input-quantum" min="0" max="0.8" step="0.01" value="0.1">
        <div class="algebra-tag">
           <span style="font-size:0.75rem; color:var(--text-dim); line-height:1.4;">
             Increases CPTP map entropy.<br>High noise threatens contractivity.
           </span>
        </div>
      </div>
      
      <div style="margin-top: auto; padding: 1rem; background: rgba(59, 130, 246, 0.1); border: 1px solid rgba(59, 130, 246, 0.2); border-radius: 0.5rem;">
        <div style="font-size: 0.75rem; font-weight: bold; color: var(--accent); margin-bottom: 0.5rem; text-transform: uppercase;">Worked Example</div>
        <div style="font-size: 0.8rem; color: var(--text-dim); font-family: monospace;">
          1. u = min(1, s + r)<br>
          2. U = uI<br>
          3. E' = U # E
        </div>
      </div>
    </div>

    <!-- Center: Visualization -->
    <div class="panel" style="padding:0; overflow:hidden;">
      <div id="viz-container">
        <svg id="connections">
          <path id="path-fuzzy" d="" stroke="var(--fuzzy)" />
          <path id="path-classical" d="" stroke="var(--classical)" />
          <path id="path-out" d="" stroke="white" />
        </svg>

        <!-- Nodes overlaid absolutely -->
        <div class="node fuzzy" id="node-fuzzy" style="position:absolute; left: 15%; top: 25%;">
          <span class="node-label">Fuzzy</span>
          <span class="node-val" id="disp-fuzzy">0.50</span>
        </div>
        
        <div class="node classical" id="node-class" style="position:absolute; left: 15%; top: 75%;">
          <span class="node-label">Classical</span>
          <span class="node-val" id="disp-classical">0</span>
        </div>

        <div class="node fusion" id="node-fusion" style="position:absolute; left: 50%; top: 50%; transform: translate(-50%, -50%);">
          <i data-lucide="git-merge" size="20" style="color:var(--text-dim); margin-bottom:4px;"></i>
          <span class="node-label">Fusion</span>
          <span class="node-val" id="disp-fusion">0.50</span>
          <span style="font-size:0.6rem; color:var(--text-dim); margin-top:4px;">MV Algebra</span>
        </div>

        <div class="node quantum" id="node-quantum" style="position:absolute; right: 15%; top: 50%; transform: translateY(-50%);">
          <span class="node-label" style="color:var(--quantum)">Quantum State</span>
          <div class="q-matrix">
            <div class="q-cell" id="q-00">1.00</div>
            <div class="q-cell" id="q-01">0.00</div>
            <div class="q-cell" id="q-10">0.00</div>
            <div class="q-cell" id="q-11">0.00</div>
          </div>
          <span style="font-size:0.6rem; color:var(--quantum); margin-top:8px;">Effect E ∈ [0, I]</span>
        </div>
        
        <!-- Fail Overlay -->
        <div id="fail-overlay">
           <div class="fail-box">
             <i data-lucide="shield-alert" size="48" style="color:var(--error); margin-bottom:1rem;"></i>
             <div class="fail-title">Safety Violation</div>
             <p class="fail-desc">
               The Contractive Safety Projection (CSP) detected a SlopeUB violation (> 1.0). 
               The system has failed-closed to prevent undefined behavior.
             </p>
             <button class="reset-btn" onclick="resetSystem()">Reset System</button>
           </div>
        </div>
      </div>
    </div>

    <!-- Right: CSP Monitor -->
    <div class="panel">
      <div class="panel-title">
        <i data-lucide="shield-check" size="14"></i>
        <span>CSP Kernel Monitor</span>
      </div>

      <div class="metric-row">
        <span class="metric-label">Lipschitz Bound (L)</span>
        <span class="metric-value" id="val-lipschitz">1.00</span>
      </div>
      <div class="metric-row">
        <span class="metric-label">Step Size (α)</span>
        <span class="metric-value" id="val-alpha">0.10</span>
      </div>
      <div class="metric-row">
        <span class="metric-label">SlopeUB</span>
        <span class="metric-value" id="val-slope" style="color:var(--success)">0.450</span>
      </div>
      <div class="metric-row">
        <span class="metric-label">GapLB</span>
        <span class="metric-value" id="val-gap">0.550</span>
      </div>

      <div class="panel-title" style="margin-top: 1rem;">
        <i data-lucide="file-signature" size="14"></i>
        <span>Signature Audit</span>
      </div>
      <div style="background: #000; padding: 0.75rem; border-radius: 0.5rem; border: 1px solid var(--border);">
        <div style="font-family: monospace; font-size: 0.7rem; color: var(--text-dim); line-height: 1.6;">
          <div><span style="color:#52525b">IN:</span> <span style="color:var(--fuzzy)">logic.fuzzy</span> + <span style="color:var(--classical)">logic.classical</span></div>
          <div><span style="color:#52525b">OP:</span> <span style="color:var(--quantum)">quantum_lift</span> ⊕ <span style="color:#fff">mv_fuse</span></div>
          <div><span style="color:#52525b">OUT:</span> <span style="color:var(--quantum)">logic.quantum.effect</span></div>
          <div style="border-top: 1px dashed #333; margin-top: 4px; padding-top: 4px; color: var(--success);">✔ Signature Conserved</div>
        </div>
      </div>

      <div class="panel-title" style="margin-top: auto;">
        <i data-lucide="terminal" size="14"></i>
        <span>Kernel Log</span>
      </div>
      <div class="log-container" id="logger">
        <!-- Logs appear here -->
      </div>
    </div>
  </main>

<script>
  lucide.createIcons();

  // State
  const state = {
    s: 0.5, // fuzzy
    r: 0,   // classical
    noise: 0.1,
    fused: 0.5,
    failed: false
  };

  // Elements
  const ui = {
    fuzzyIn: document.getElementById('input-fuzzy'),
    classIn: document.getElementById('input-classical'),
    noiseIn: document.getElementById('input-quantum'),
    valFuzzy: document.getElementById('val-fuzzy'),
    valClass: document.getElementById('val-classical'),
    valNoise: document.getElementById('val-quantum'),
    
    dispFuzzy: document.getElementById('disp-fuzzy'),
    dispClass: document.getElementById('disp-classical'),
    dispFusion: document.getElementById('disp-fusion'),
    
    slope: document.getElementById('val-slope'),
    gap: document.getElementById('val-gap'),
    lipschitz: document.getElementById('val-lipschitz'),
    
    viz: document.getElementById('viz-container'),
    nodeFuzzy: document.getElementById('node-fuzzy'),
    nodeClass: document.getElementById('node-class'),
    nodeFusion: document.getElementById('node-fusion'),
    nodeQuantum: document.getElementById('node-quantum'),
    
    paths: {
      fuzzy: document.getElementById('path-fuzzy'),
      classical: document.getElementById('path-classical'),
      out: document.getElementById('path-out')
    },
    
    qCells: [
      document.getElementById('q-00'), document.getElementById('q-01'),
      document.getElementById('q-10'), document.getElementById('q-11')
    ],
    
    logger: document.getElementById('logger'),
    failOverlay: document.getElementById('fail-overlay'),
    statusText: document.getElementById('status-text'),
    statusDot: document.getElementById('status-dot')
  };

  function log(msg, type='info') {
    const line = document.createElement('div');
    line.className = 'log-line ' + type;
    const time = new Date().toLocaleTimeString().split(' ')[0];
    line.innerHTML = \`<span style="opacity:0.5">\${time}</span> \${msg}\`;
    ui.logger.prepend(line);
    if (ui.logger.children.length > 20) ui.logger.lastChild.remove();
  }

  function drawConnections() {
    if (state.failed) return;
    
    const getPos = (el) => {
      const rect = el.getBoundingClientRect();
      const cont = ui.viz.getBoundingClientRect();
      return {
        x: rect.left + rect.width/2 - cont.left,
        y: rect.top + rect.height/2 - cont.top
      };
    };

    const f = getPos(ui.nodeFuzzy);
    const c = getPos(ui.nodeClass);
    const m = getPos(ui.nodeFusion);
    const q = getPos(ui.nodeQuantum);

    const draw = (p1, p2) => {
      const mx = (p1.x + p2.x) / 2;
      return \`M \${p1.x} \${p1.y} C \${mx} \${p1.y}, \${mx} \${p2.y}, \${p2.x} \${p2.y}\`;
    };

    ui.paths.fuzzy.setAttribute('d', draw(f, m));
    ui.paths.classical.setAttribute('d', draw(c, m));
    ui.paths.out.setAttribute('d', draw(m, q));
  }

  // Initial draw
  setTimeout(drawConnections, 100);
  window.addEventListener('resize', drawConnections);

  function resetSystem() {
    state.failed = false;
    state.noise = 0.1;
    ui.noiseIn.value = 0.1;
    ui.failOverlay.classList.remove('active');
    updateSystem();
    log('System reset by operator.', 'info');
  }

  window.resetSystem = resetSystem;

  function updateSystem() {
    if (state.failed) return;

    // 1. Inputs
    state.s = parseFloat(ui.fuzzyIn.value);
    state.r = ui.classIn.checked ? 1 : 0;
    state.noise = parseFloat(ui.noiseIn.value);

    // Update Input UI
    ui.valFuzzy.textContent = state.s.toFixed(2);
    ui.valClass.textContent = state.r ? "TRUE" : "FALSE";
    ui.valNoise.textContent = state.noise.toFixed(2);
    
    ui.dispFuzzy.textContent = state.s.toFixed(2);
    ui.dispClass.textContent = state.r;

    // 2. Fusion (MV Algebra)
    // u = min(1, s + r)
    const rawSum = state.s + state.r;
    state.fused = Math.min(1, rawSum);
    ui.dispFusion.textContent = state.fused.toFixed(2);

    // 3. CSP Check
    // We simulate Lipschitz bound increasing with noise and signal volatility
    // L = 1 + (noise * 5)
    // SlopeUB = (1-a) + a*L. Let a=0.1
    const alpha = 0.1;
    const L = 1 + (state.noise * 3); 
    const slopeUB = (1 - alpha) + (alpha * L);
    const gapLB = 1 - slopeUB;

    ui.lipschitz.textContent = L.toFixed(2);
    ui.slope.textContent = slopeUB.toFixed(3);
    ui.gap.textContent = gapLB.toFixed(3);

    // Color code metrics
    if (slopeUB > 0.9) ui.slope.style.color = 'var(--warn)';
    if (slopeUB <= 0.9) ui.slope.style.color = 'var(--success)';

    // Fail Condition
    if (slopeUB >= 1.0) {
      triggerFailClosed(slopeUB);
      return;
    }

    // 4. Quantum Update (if safe)
    // Simple mock: Diagonal matrix based on fused val, off-diagonal based on noise
    const diag = state.fused;
    const off = (Math.random() - 0.5) * state.noise;
    
    // Normalize slightly to look realistic (trace <= 1)
    const q00 = (diag * (1-state.noise)).toFixed(2);
    const q11 = ((1-diag) * (1-state.noise)).toFixed(2);
    const q01 = off.toFixed(2);
    
    ui.qCells[0].textContent = q00;
    ui.qCells[3].textContent = q11;
    ui.qCells[1].textContent = q01;
    ui.qCells[2].textContent = q01; // Symmetric

    // Visual flow
    ui.paths.fuzzy.style.strokeDashoffset = parseInt(Date.now() / 10) % 1000;
    ui.paths.classical.style.strokeDashoffset = parseInt(Date.now() / 10) % 1000;
  }

  function triggerFailClosed(slopeVal) {
    state.failed = true;
    ui.failOverlay.classList.add('active');
    ui.statusText.textContent = "CSP: HALTED";
    ui.statusDot.style.background = "var(--error)";
    ui.statusDot.style.boxShadow = "0 0 8px var(--error)";
    log(\`CRITICAL: SlopeUB \${slopeVal.toFixed(3)} >= 1.0\`, 'error');
    log('System transitioned to Fail-Closed state.', 'error');
  }

  // Loop for animation
  function animate() {
    if (!state.failed) {
      const offset = (Date.now() / 20) % 1000; // Speed of flow
      ui.paths.fuzzy.style.strokeDashoffset = -offset;
      ui.paths.classical.style.strokeDashoffset = -offset;
      ui.paths.out.style.strokeDashoffset = -offset;
    }
    requestAnimationFrame(animate);
  }
  animate();

  // Listeners
  ui.fuzzyIn.addEventListener('input', updateSystem);
  ui.classIn.addEventListener('change', () => { updateSystem(); log(\`Classical trigger \${state.r ? 'ENGAGED' : 'DISENGAGED'}\`); });
  ui.noiseIn.addEventListener('input', updateSystem);

  // Initial Log
  log('Universal Logic v2.1+ Kernel initialized.');
  log('CSP Monitor active. Mode: SAFE');
  updateSystem();

</script>
</body>
</html>`;